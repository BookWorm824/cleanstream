// CleanStream on Netflix and Prime Video (and Hulu and the others): gets
// the English subtitles through the site's page script (netflix_page.js / prime_page.js), works
// out what to mute with CleanView's word lists (captions.js), keeps the sound off from the start
// of a title until that's done, and mutes at the right moments. Their subtitles give a line at a
// time, so each word's moment is guessed within its line and muted a little wider (as YouTube's
// written captions). What differs per site is in CS_SITE (site_netflix.js / site_prime.js).
(function () {
  if (window.__cleanstreamSite) return;
  window.__cleanstreamSite = true;
  const TAG = "cleanstream", SITE = globalThis.CS_SITE;
  const CC = globalThis.CSCaptions, CS = globalThis.CSWords, S = globalThis.CSSettings;
  const st = { video: null, settings: null, ticks: null, tracks: null, plan: null, ranges: [],
    status: "", captions: "waiting", weMuted: false, holding: false };
  globalThis.__cleanstreamState = st;

  // ---------- the status line ----------
  let pill, pillTimer;
  function say(text, secs = 6) {
    st.status = text;
    const host = SITE.host() || document.body;
    if (!pill || !host.contains(pill)) {
      pill = document.createElement("div");
      pill.id = "cleanstream-status";
      pill.style.cssText = "position:fixed;top:14px;left:14px;z-index:2147483646;max-width:60%;" +
        "padding:7px 12px;border-radius:14px;background:rgba(20,40,35,.85);color:#fff;" +
        "font:500 15px/1.35 'Segoe UI',Arial,sans-serif;pointer-events:none;transition:opacity .4s;";
      host.appendChild(pill);
    }
    pill.textContent = text;
    pill.style.opacity = "1";
    clearTimeout(pillTimer);
    if (secs) pillTimer = setTimeout(() => { pill.style.opacity = "0"; }, secs * 1000);
  }

  const videoEl = () => SITE.video();

  // ---------- muting ----------
  function inRange(t, ranges, lead) {
    let lo = 0, hi = ranges.length - 1;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (ranges[mid][0] <= t + lead) lo = mid + 1; else hi = mid - 1; }
    return hi >= 0 && t < ranges[hi][1];
  }
  // the element we muted is remembered: the site can swap its video for another mid-title
  let mutedEl = null;
  function mute() { const v = videoEl(); if (v && !v.muted) { v.muted = true; st.weMuted = true; mutedEl = v; } }
  function unmute() {
    const v = mutedEl || videoEl();
    if (st.weMuted && v) v.muted = false;
    st.weMuted = false; mutedEl = null;
  }
  // Ads played inside the title's own video (stitched in: Prime) push its clock on. Each one's
  // length is noted while it plays and taken off the clock (the owner, 2026-11-19: after four
  // ads CleanStream's clock was 110 seconds ahead, and listed words played).
  let adSpans = [], curAd = null, spanEl = null;
  function noteAd(v, ad) {
    if (v !== spanEl) { adSpans = []; curAd = null; spanEl = v; }
    const t = v.currentTime;
    if (ad && !(isFinite(v.duration) && v.duration <= AD_LONGEST)) {      // an ad inside the title's video
      if (!curAd || t < curAd.to - 1) curAd = { from: t, to: t };
      else curAd.to = t;
    } else if (curAd) {
      curAd.to = Math.max(curAd.to, Math.min(t, curAd.to + 1));          // the show starts here
      if (curAd.to - curAd.from > 0.5 && !adSpans.some(s => Math.abs(s.from - curAd.from) < 1)) adSpans.push(curAd);
      curAd = null;
    }
  }
  const adTime = t => adSpans.reduce((sum, s) => s.to <= t + 0.5 ? sum + (s.to - s.from) : sum, 0);
  /** Where the title is: the site's own clock on screen when it can be read, else the video's
   *  clock with the ads taken off. */
  function titleTime(v) {
    const s = SITE.time ? SITE.time(v) : { t: v.currentTime, ad: false };
    return s.clocked ? s : { ...s, t: v.currentTime - adTime(v.currentTime) };
  }
  // An ad played as its own short video (Prime; the owner, 2026-11-19: "it mutes thing on the
  // ad also"): a video much shorter than the title's subtitles run isn't the title. Ads are
  // left alone, as on YouTube.
  const AD_LONGEST = 150;
  function isAd(v) {
    if (SITE.adShowing && SITE.adShowing()) return true;
    const d = v.duration;
    return isFinite(d) && d > 0 && d <= AD_LONGEST && st.lastCue > d + 60;
  }
  function tick() {
    const v = videoEl();
    if (!v || !st.settings || !st.settings.on || !st.video) return;
    if (st.weMuted && mutedEl && mutedEl !== v) unmute();       // swapped: let the old one go
    const rate = v.playbackRate || 1;
    const ad = isAd(v);
    noteAd(v, ad);
    const at = ad ? { t: 0, ad: true } : titleTime(v);
    const want = !ad && (st.holding || (!v.paused && !at.ad && inRange(at.t, st.ranges, 0.08 * rate)));
    if (want && !v.muted) mute();
    else if (!want && st.weMuted) unmute();
  }
  setInterval(tick, 20);
  document.addEventListener("seeked", tick, true);
  document.addEventListener("play", tick, true);
  document.addEventListener("playing", tick, true);
  document.addEventListener("loadstart", tick, true);
  document.addEventListener("volumechange", e => {
    if (e.target !== videoEl() || e.target.muted) return;
    if (st.weMuted) st.weMuted = false;
    tick();
  }, true);

  // ---------- subtitles ----------
  const HOLD_MOST = SITE.holdMost || 30;
  let holdTimer = null;
  function hold(on) {
    st.holding = on;
    clearTimeout(holdTimer);
    if (on) holdTimer = setTimeout(() => {
      if (!st.holding) return;
      st.holding = false;
      say(SITE.noSubsHint || ("CleanStream couldn't get this title's subtitles in time, so bad language won't be muted. " +
        "Reloading the page may help."), 12);
    }, HOLD_MOST * 1000);
    tick();
  }

  // Subtitles that come in pieces as the video plays (Disney+, Max...: only with subtitles turned
  // on): each piece's lines are added, and the plan made again.
  let pieces = new Map(), whole = false, replanTimer = null;
  function pieceArrived(d) {
    if (d.title !== st.video || whole) return;
    let cues = null;
    try { cues = CC.readSubtitles(d.text); } catch (e) { cues = null; }
    if (!(cues && cues.length)) return;
    const before = pieces.size;
    for (const c of cues) pieces.set(c.s.toFixed(2) + "|" + c.text, c);
    if (pieces.size === before) return;
    const first = st.captions !== "ok";
    st.tracks = { written: [...pieces.values()].sort((a, b) => a.s - b.s), auto: null };
    st.captions = "ok";
    hold(false);
    clearTimeout(replanTimer);
    replanTimer = setTimeout(replan, first ? 0 : 300);
    if (first) say("CleanStream is reading this title's subtitles as they come, and muting from them.", 6);
  }
  function replan() {
    if (!st.tracks || !st.settings) return;
    st.ticks = S.ticksFor(st.settings);
    st.lastCue = Math.max(0, ...(st.tracks.written || []).map(c => c.e || 0));
    st.plan = CC.plan(st.tracks, st.ticks, st.settings.mine);
    st.ranges = st.settings.on ? CC.ranges(st.plan.mutes) : [];
    chrome.runtime.sendMessage({ type: "found", video: st.video, count: st.plan.mutes.length }).catch(() => {});
  }
  function subsArrived(d) {
    if (d.title !== st.video) return;
    if (st.captions === "ok" && !d.text) return;      // already muting from them: not news
    hold(false);
    // bad news waits a few seconds: on Prime and the others the subtitles can still come another
    // way (a later answer, or the player's own download), and then it was never true
    const sayLater = (text, secs) => {
      const id = st.video;
      setTimeout(() => { if (st.video === id && st.captions !== "ok") say(text, secs); }, SITE.ask ? 0 : 6000);
    };
    if (d.none) {
      st.captions = "none";
      sayLater(d.others ? "CleanStream: this title only has subtitles in another language, so bad language can't be muted yet."
        : "CleanStream: this title has no subtitles, so bad language can't be muted.", 9);
      return;
    }
    let cues = null;
    try { cues = d.text ? CC.readSubtitles(d.text) : null; } catch (e) { cues = null; }
    if (!(cues && cues.length)) {
      if (st.captions === "ok") return;
      st.captions = "empty";
      sayLater("CleanStream couldn't read this title's subtitles, so bad language won't be muted. Reloading the page may help.", 10);
      return;
    }
    st.tracks = { written: cues, auto: null };
    st.captions = "ok";
    whole = true;
    replan();
    const n = st.plan.mutes.length;
    say(n ? `CleanStream: ${n} ${n === 1 ? "word or phrase" : "words or phrases"} will be muted.`
      : "CleanStream: nothing to mute in this title's subtitles.");
  }

  function startTitle(id) {
    st.video = id; st.tracks = null; st.plan = null; st.ranges = []; st.captions = "waiting"; st.lastCue = 0;
    pieces = new Map(); whole = false;
    if (SITE.newTitle) SITE.newTitle();
    spanEl = null;                                   // a new title: its own ads
    unmute(); hold(false);
    if (!id || !st.settings || !st.settings.on) return;
    hold(true);
    say("CleanStream is getting this title's subtitles (the sound is off until it's ready)…", 0);
    if (SITE.ask) window.postMessage({ [TAG]: SITE.contentTag, type: "get-subs", title: id }, "*");
  }
  let pending = null;            // subtitles that came before the title was known (Prime)
  // messages that come before the settings are loaded wait for them (a plan can't be made
  // without them: the subtitles were dropped, and only a refresh helped; 2026-11-19)
  let ready = false;
  const early = [];
  window.addEventListener("message", e => {
    const d = e.data;
    if (e.source !== window || !d || d[TAG] !== SITE.pageTag) return;
    if (!ready) { early.push(d); return; }
    handle(d);
  });
  function handle(d) {
    // Prime: the page script says which title is starting (no address to watch)
    if (d.type === "title" && !SITE.titleFromUrl && d.title !== st.video) {
      startTitle(d.title);
      if (pending && pending.title === d.title) { subsArrived(pending); pending = null; }
    }
    if (d.type === "subs-done") { if (d.title === st.video) subsArrived(d); else pending = d; }
    // a subtitle file the player downloaded itself, when the list's own fetch failed
    if (d.type === "subs-seen" && d.title === st.video && st.captions !== "ok") subsArrived({ title: d.title, text: d.text });
    if (d.type === "subs-piece") pieceArrived(d);
  }

  // ---------- following the page's changes (neither site reloads between titles) ----------
  function check() {
    if (!(chrome.runtime && chrome.runtime.id) && !st.toldUpdated) {
      st.toldUpdated = true;
      say("CleanStream was updated. Press F5 to use the new version.", 12);
    }
    if (!SITE.titleFromUrl) return;
    const id = SITE.titleFromUrl();
    if (id !== st.video) startTitle(id);
  }
  setInterval(check, 500);

  chrome.storage.onChanged.addListener(async (changes, area) => {
    if (area !== "sync") return;
    const was = st.settings && st.settings.on;
    st.settings = await S.load();
    if (!st.settings.on) { st.ranges = []; hold(false); unmute(); return; }
    if (!was) { st.video = null; check(); return; }
    replan();
  });

  // ---------- the settings window asks what was found ----------
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg.type !== "state") return;
    const v = videoEl();
    reply({ video: st.video, title: document.title, captions: st.captions,
      status: st.status, source: st.plan && "subtitles", now: v ? titleTime(v).t : 0,
      // where CleanStream thinks the title is, to compare with the site's own clock (Prime's ads
      // can move the video's clock; the owner, 2026-11-19: listed words played)
      clock: v ? titleTime(v).t : null, ad: v ? isAd(v) : false,
      mutes: st.plan ? st.plan.mutes.map(m => ({ s: m.s, text: CS.mask(m.text), why: m.why, guess: false })) : [],
      left: st.plan ? st.plan.left.map(m => ({ s: m.s, text: m.text, why: m.why })) : [],
      site: SITE.name });
  });

  (async () => {
    st.settings = await S.load();
    ready = true;
    check();
    for (const d of early.splice(0)) handle(d);
    // anything the page script had before this part was listening is sent again
    window.postMessage({ [TAG]: SITE.contentTag, type: "hello" }, "*");
  })();
})();
